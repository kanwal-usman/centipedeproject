/*
 * Position.h
 *
 *  Created on: May 1, 2019
 *      Author: aleezeh
 */

#ifndef POSITION_H_
#define POSITION_H_

class Position {
public:
	int x;
	int y;
public:
	Position();
	Position(int , int);
	virtual ~Position();
};

#endif /* POSITION_H_ */
