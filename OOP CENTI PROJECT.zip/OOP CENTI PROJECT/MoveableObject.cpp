/*
 * MoveableObject.cpp
 *
 *  Created on: May 1, 2019
 *      Author: aleezeh
 */

#include "MoveableObject.h"

MoveableObject::MoveableObject() {
	//cout<<"const moveable"<<endl;

}

MoveableObject::~MoveableObject() {
	//cout<<"testing moveable"<<endl;
}

