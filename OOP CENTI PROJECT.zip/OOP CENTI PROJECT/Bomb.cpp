/*
 * Bomb.cpp
 *
 *  Created on: May 1, 2019
 *      Author: aleezeh
 */

#include "Bomb.h"

Bomb::Bomb() {
cout<<"const bomb"<<endl;
}
void Bomb::setBomb(int x, int y){
	pos.x = x;
	pos.y = y;
cout<<"setting bomb"<<endl;;
}
void Bomb::draw(){
	if(direction == 3)
	DrawRectangle( pos.x*17+9 , pos.y*14+15 ,10,25,colors[CRIMSON]);
//	cout<<"position of bomb while drawing :  "<<pos.x<<"  "<<pos.y<<endl;
}
void Bomb::move(){
	if(direction == 3) pos.y += 1;
	//cout<<"position of bomb while moving:  "<<pos.x<<"  "<<pos.y<<endl;
	if(pos.y > 55){ direction = 0;}
}
int Bomb::getX(){
	return pos.x;
}
int Bomb::getY(){
	return pos.y;
}
int Bomb::getDirection(){
	return direction;
}
void Bomb::setDirection(int dir){
	direction = dir;
}
void Bomb::collision(int x,int y){
//nothing to do here
}
Bomb::~Bomb() {
	// TODO Auto-generated destructor stub
	cout<<"testing"<<endl;
}

